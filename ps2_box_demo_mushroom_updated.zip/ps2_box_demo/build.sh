#!/bin/bash
# Build ELF di Docker PS2DEV, lalu buat ISO.
set -e
cd "$(dirname "$0")"

if [ ! -f mushroom_model.h ]; then
  echo "ERROR: mushroom_model.h tidak ditemukan. Pastikan file model ada di folder proyek."
  exit 1
fi

if ! command -v docker >/dev/null 2>&1; then
  echo "ERROR: Docker tidak ditemukan. Aktifkan Docker di Codespaces/Linux lalu ulangi."
  exit 1
fi

echo "== 1/3 Compile ELF (PS2DEV Docker) =="
docker run --rm -v "$PWD":/src -w /src ps2dev/ps2dev:latest \
  sh -c "make clean && make"

echo "== 2/3 Siapkan isi ISO =="
rm -rf iso && mkdir iso
cp BOXDEMO.ELF iso/BOXDEMO.ELF
printf 'BOOT2 = cdrom0:\\BOXDEMO.ELF;1\r\nVER = 1.00\r\nVMODE = NTSC\r\n' > iso/SYSTEM.CNF

echo "== 3/3 Bikin ISO =="
if command -v mkisofs >/dev/null 2>&1; then
  mkisofs -l -iso-level 1 -V BOXDEMO -o boxdemo.iso iso
elif command -v genisoimage >/dev/null 2>&1; then
  genisoimage -l -iso-level 1 -V BOXDEMO -o boxdemo.iso iso
elif command -v xorriso >/dev/null 2>&1; then
  xorriso -as mkisofs -l -iso-level 1 -V BOXDEMO -o boxdemo.iso iso
else
  echo "Tool ISO tidak ada di host; mencoba dari container PS2DEV..."
  docker run --rm -v "$PWD":/src -w /src ps2dev/ps2dev:latest sh -c \
    'if command -v mkisofs >/dev/null 2>&1; then mkisofs -l -iso-level 1 -V BOXDEMO -o boxdemo.iso iso; elif command -v genisoimage >/dev/null 2>&1; then genisoimage -l -iso-level 1 -V BOXDEMO -o boxdemo.iso iso; elif command -v xorriso >/dev/null 2>&1; then xorriso -as mkisofs -l -iso-level 1 -V BOXDEMO -o boxdemo.iso iso; else echo "ERROR: mkisofs/genisoimage/xorriso tidak tersedia"; exit 1; fi'
fi

echo "Selesai: boxdemo.iso dan BOXDEMO.ELF"
