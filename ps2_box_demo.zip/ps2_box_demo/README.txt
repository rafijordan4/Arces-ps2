BOX DEMO PS2 - kotak putih di ruangan putih

Kontrol: stick kiri/D-pad = jalan, stick kanan = putar kamera, Segitiga = loncat, X (tahan) = jongkok

Build (di Codespaces):
  bash build.sh
Hasil: boxdemo.iso dan BOXDEMO.ELF
