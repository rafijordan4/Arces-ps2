#!/usr/bin/env python3
"""
Generator karakter "Jamur Imut" untuk PS2 -> mushroom_model.h

Jalankan:  python3 tools/gen_mushroom.py
Hasil   :  mushroom_model.h (data mesh, rangka, dan animasi untuk main.c)

Mesh dibuat dari bentuk bulat (lathe/ellipsoid/capsule), tiap bagian menempel
ke satu tulang (rigid), normal per-vertex dipakai untuk shading halus (gouraud).
Ubah Q (di bawah) untuk menaikkan/menurunkan jumlah segitiga.
"""
import math, sys
import numpy as np

Q = 1.0   # 1.0 = default (~1900 segitiga). 0.7 = lebih ringan, 1.3 = lebih halus.
def S(n): return max(4, int(round(n * Q)))

# ---------------------------------------------------------------- warna
CREAM = (245, 227, 191); RED = (214, 52, 46); WHITE = (250, 246, 232)
TAN = (233, 214, 172); DARK = (28, 20, 18); MOUTH = (140, 54, 48)
CHEEK = (244, 160, 160); FOOT = (196, 150, 98); HL = (255, 255, 255)

# ---------------------------------------------------------------- tulang
NAMES = ["root", "torso", "head",
         "uarmL", "farmL", "handL", "uarmR", "farmR", "handR",
         "thighL", "shinL", "thighR", "shinR"]
BI = {n: i for i, n in enumerate(NAMES)}
NB = len(NAMES)
PARENT = [-1, 0, 1, 1, 3, 4, 1, 6, 7, 0, 9, 0, 11]

SH_X, SH_Y = 0.32, 0.80
ARM_ANG = math.radians(40)
UP_L, FO_L = 0.20, 0.18

def arm_pts(s):
    d = np.array([s * math.sin(ARM_ANG), -math.cos(ARM_ANG), 0.0])
    S0 = np.array([s * SH_X, SH_Y, 0.0]); E = S0 + d * UP_L; W = E + d * FO_L
    return d, S0, E, W

PIVOT = np.zeros((NB, 3))
PIVOT[BI["root"]] = (0, 0.45, 0); PIVOT[BI["torso"]] = (0, 0.45, 0)
PIVOT[BI["head"]] = (0, 0.95, 0)
for s, sfx in ((1, "L"), (-1, "R")):
    d, S0, E, W = arm_pts(s)
    PIVOT[BI["uarm" + sfx]] = S0; PIVOT[BI["farm" + sfx]] = E; PIVOT[BI["hand" + sfx]] = W
    PIVOT[BI["thigh" + sfx]] = (s * 0.14, 0.44, 0); PIVOT[BI["shin" + sfx]] = (s * 0.14, 0.25, 0)

# ---------------------------------------------------------------- mesh util
class Mesh:
    def __init__(self):
        self.P = []; self.N = []; self.C = []; self.B = []; self.T = []; self.tag = []
    def add(self, P, N, tris, color, bone, tag=""):
        base = len(self.P); P = np.asarray(P, float); N = np.asarray(N, float)
        for (a, b, c) in tris:
            fn = np.cross(P[b] - P[a], P[c] - P[a])
            if np.linalg.norm(fn) < 1e-12:
                continue
            if np.dot(fn, N[a] + N[b] + N[c]) < 0:
                b, c = c, b
            self.T.append((base + a, base + b, base + c))
        for p, n in zip(P, N):
            self.P.append(p); self.N.append(n / max(np.linalg.norm(n), 1e-9))
            self.C.append(color); self.B.append(bone); self.tag.append(tag)

def axis_rot(a):
    a = np.asarray(a, float); a = a / np.linalg.norm(a)
    y = np.array([0, 1.0, 0]); v = np.cross(y, a); s = np.linalg.norm(v); c = float(np.dot(y, a))
    if s < 1e-9:
        return np.eye(3) if c > 0 else np.diag([1, -1, -1.0])
    vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + vx + vx @ vx * ((1 - c) / (s * s))

def lathe(profile, seg, scale=(1, 1, 1), R=None, origin=(0, 0, 0)):
    prof = np.array(profile, float); n = len(prof); n2 = []
    for i in range(n):
        i0 = max(i - 1, 0); i1 = min(i + 1, n - 1)
        dr = prof[i1, 0] - prof[i0, 0]; dh = prof[i1, 1] - prof[i0, 1]
        l = math.hypot(dh, dr) or 1.0
        n2.append((dh / l, -dr / l))
    P = []; N = []
    for i in range(n):
        for j in range(seg):
            th = 2 * math.pi * j / seg; c, s = math.cos(th), math.sin(th)
            P.append((prof[i, 0] * c, prof[i, 1], prof[i, 0] * s))
            N.append((n2[i][0] * c, n2[i][1], n2[i][0] * s))
    tris = []
    for i in range(n - 1):
        for j in range(seg):
            j1 = (j + 1) % seg
            a = i * seg + j; b = i * seg + j1; c = (i + 1) * seg + j1; d = (i + 1) * seg + j
            tris += [(a, b, c), (a, c, d)]
    sc = np.array(scale, float)
    P = np.array(P) * sc; N = np.array(N) / sc
    if R is not None:
        P = P @ R.T; N = N @ R.T
    return P + np.array(origin, float), N, tris

def ellipsoid(M, center, radii, seg, rings, color, bone, tag=""):
    prof = [(math.sin(math.pi * k / rings), -math.cos(math.pi * k / rings)) for k in range(rings + 1)]
    P, N, T = lathe(prof, seg, scale=radii, origin=center); M.add(P, N, T, color, bone, tag)

def capsule(M, p0, p1, r0, r1, seg, color, bone, tag=""):
    p0 = np.array(p0, float); p1 = np.array(p1, float); d = p1 - p0; L = float(np.linalg.norm(d)); q = math.pi / 4
    prof = [(0, -r0), (r0 * math.sin(q), -r0 * math.cos(q)), (r0, 0), (r1, L),
            (r1 * math.sin(q), L + r1 * math.cos(q)), (0, L + r1)]
    P, N, T = lathe(prof, seg, R=axis_rot(d), origin=p0); M.add(P, N, T, color, bone, tag)

def finger(M, base, direction, length, r0, r1, color, bone):
    prof = [(r0, 0), (r1, length), (r1 * 0.7, length + 0.5 * r1), (0, length + 0.95 * r1)]
    P, N, T = lathe(prof, 4, R=axis_rot(direction), origin=base); M.add(P, N, T, color, bone, "finger")

def unit(v):
    v = np.asarray(v, float); return v / np.linalg.norm(v)

def surface_disc(M, p, n, t1, rad, lift, seg, color, bone, tag=""):
    n = unit(n); t1 = unit(t1 - n * np.dot(n, t1)); t2 = np.cross(n, t1)
    P = []; N = []
    for rf, lf in ((1.0, 0.35), (0.62, 0.8)):
        for j in range(seg):
            a = 2 * math.pi * j / seg
            P.append(p + n * lift * lf + (math.cos(a) * t1 + math.sin(a) * t2) * rad * rf); N.append(n)
    P.append(p + n * lift); N.append(n)
    tris = []
    for j in range(seg):
        j1 = (j + 1) % seg
        tris += [(j, j1, seg + j1), (j, seg + j1, seg + j), (seg + j, seg + j1, 2 * seg)]
    M.add(P, N, tris, color, bone, tag)

# ---------------------------------------------------------------- model
CAP = [(0.66, 1.34), (0.675, 1.375), (0.64, 1.46), (0.55, 1.58), (0.40, 1.70), (0.20, 1.775), (0.0, 1.80)]
HC = np.array([0, 1.08, 0.0]); HR = np.array([0.36, 0.30, 0.34])

def cap_surface(theta, u):
    i = int(math.floor(u)); f = u - i
    if i >= len(CAP) - 1: i = len(CAP) - 2; f = 1.0
    r = CAP[i][0] * (1 - f) + CAP[i + 1][0] * f; h = CAP[i][1] * (1 - f) + CAP[i + 1][1] * f
    dr = CAP[i + 1][0] - CAP[i][0]; dh = CAP[i + 1][1] - CAP[i][1]; l = math.hypot(dr, dh)
    nr, nh = dh / l, -dr / l; c, s = math.cos(theta), math.sin(theta)
    return np.array([r * c, h, r * s]), np.array([nr * c, nh, nr * s])

def head_point(x, y):
    q = 1 - (x / HR[0]) ** 2 - ((y - HC[1]) / HR[1]) ** 2
    z = HR[2] * math.sqrt(max(q, 0.0)); p = np.array([x, y, HC[2] + z])
    n = unit([(p[0] - HC[0]) / HR[0] ** 2, (p[1] - HC[1]) / HR[1] ** 2, (p[2] - HC[2]) / HR[2] ** 2])
    return p, n

def build():
    M = Mesh(); H = BI["head"]
    # --- badan (batang jamur)
    torso = [(0, 0.37), (0.14, 0.385), (0.235, 0.45), (0.255, 0.55), (0.235, 0.70), (0.20, 0.85), (0.16, 0.95), (0, 0.97)]
    P, N, T = lathe(torso, S(10)); M.add(P, N, T, CREAM, BI["torso"], "torso")
    # --- kepala + topi
    ellipsoid(M, HC, HR, S(12), S(8), CREAM, H, "head")
    P, N, T = lathe(CAP, S(14)); M.add(P, N, T, RED, H, "cap")
    P, N, T = lathe([(0.0, 1.37), (0.40, 1.355), (0.66, 1.34)], S(14)); M.add(P, N, T, TAN, H, "under")
    for th, u, rad in ((265, 3.2, 0.09), (215, 2.5, 0.07), (320, 2.6, 0.075), (170, 3.6, 0.085), (20, 3.4, 0.08),
                       (95, 3.2, 0.085), (250, 4.5, 0.06), (130, 4.4, 0.06), (300, 1.6, 0.06)):
        t = math.radians(th); p, n = cap_surface(t, u)
        surface_disc(M, p, n, [-math.sin(t), 0, math.cos(t)], rad, 0.016, 8, WHITE, H, "spot")
    # --- mata besar mengkilap
    for sx in (-1, 1):
        p, n = head_point(sx * 0.15, 1.07); ec = p - n * 0.012
        ellipsoid(M, ec, (0.092, 0.108, 0.06), S(9), S(5), DARK, H, "eye")
        ellipsoid(M, ec + np.array([-0.028, 0.042, 0.046]), (0.030, 0.032, 0.02), 6, 3, HL, H, "eyehl")
        ellipsoid(M, ec + np.array([0.030, -0.040, 0.046]), (0.013, 0.014, 0.012), 4, 2, HL, H, "eyehl")
    # --- mulut kecil tersenyum
    rows = []
    for x in np.linspace(-0.07, 0.07, 7):
        y = 0.935 + 0.03 * (x / 0.07) ** 2; row = []
        for yy in (y + 0.007, y - 0.007):
            p, n = head_point(x, yy); row.append((p + n * 0.005, n))
        rows.append(row)
    P = []; N = []; T = []
    for r in rows:
        for (p, n) in r: P.append(p); N.append(n)
    for i in range(len(rows) - 1):
        a, b, c, d = 2 * i, 2 * i + 1, 2 * i + 3, 2 * i + 2
        T += [(a, b, c), (a, c, d)]
    M.add(P, N, T, MOUTH, H, "mouth")
    # --- pipi merona
    for sx in (-1, 1):
        p, n = head_point(sx * 0.225, 0.985)
        surface_disc(M, p, n, np.cross(n, [0, 1, 0]), 0.048, 0.010, 8, CHEEK, H, "cheek")
    # --- tangan (bahu, siku, pergelangan, telapak, jari)
    for s, sfx in ((1, "L"), (-1, "R")):
        d, S0, E, W = arm_pts(s)
        capsule(M, S0, E, 0.058, 0.052, S(6), CREAM, BI["uarm" + sfx], "arm")
        capsule(M, E, W, 0.050, 0.046, S(6), CREAM, BI["farm" + sfx], "arm")
        hb = BI["hand" + sfx]; C = W + d * 0.05; inward = np.array([-s, 0, 0.0])
        P_, N_, T_ = lathe([(math.sin(math.pi * k / 4), -math.cos(math.pi * k / 4)) for k in range(5)], S(6),
                           scale=(0.05, 0.058, 0.038), R=axis_rot(d), origin=C)
        M.add(P_, N_, T_, CREAM, hb, "palm")
        for zoff, ln in ((-0.030, 0.058), (0.0, 0.068), (0.030, 0.058)):
            finger(M, C + d * 0.035 + np.array([0, 0, zoff]), unit(d + 0.30 * inward), ln, 0.016, 0.014, CREAM, hb)
        finger(M, C + inward * 0.032 + np.array([0, 0, 0.012]), unit(d * 0.55 + inward * 0.35 + np.array([0, 0, 0.55])),
               0.05, 0.019, 0.016, CREAM, hb)
    # --- kaki + telapak kaki terpisah
    for s, sfx in ((1, "L"), (-1, "R")):
        Hp = (s * 0.14, 0.44, 0); K = (s * 0.14, 0.25, 0); A = (s * 0.14, 0.10, 0)
        capsule(M, Hp, K, 0.078, 0.070, S(6), CREAM, BI["thigh" + sfx], "leg")
        capsule(M, K, A, 0.066, 0.060, S(6), CREAM, BI["shin" + sfx], "leg")
        ellipsoid(M, (s * 0.14, 0.07, 0.045), (0.095, 0.07, 0.15), S(8), S(5), FOOT, BI["shin" + sfx], "foot")
    return M

# ---------------------------------------------------------------- animasi
def Z(): return np.zeros((NB, 3))

def idle_pose(t):
    p = Z(); st = math.sin(t)
    p[BI["torso"]][0] = 0.02 * st; p[BI["head"]][0] = -0.02 * st; p[BI["head"]][2] = 0.04 * math.sin(t + 1.0)
    p[BI["uarmL"]][2] = 0.03 * st; p[BI["uarmR"]][2] = -0.03 * st
    p[BI["farmL"]][0] = -0.12; p[BI["farmR"]][0] = -0.12
    return p

def walk_pose(phi):
    p = Z(); s = math.sin(phi); c = math.cos(phi); A = 0.85
    p[BI["thighL"]][0] = -A * s; p[BI["thighR"]][0] = A * s
    p[BI["shinL"]][0] = 0.15 + 0.9 * max(0.0, c); p[BI["shinR"]][0] = 0.15 + 0.9 * max(0.0, -c)
    p[BI["uarmL"]][0] = 0.7 * s; p[BI["uarmR"]][0] = -0.7 * s
    p[BI["farmL"]][0] = -0.3 + 0.3 * s; p[BI["farmR"]][0] = -0.3 - 0.3 * s
    p[BI["torso"]][0] = -0.08; p[BI["torso"]][1] = 0.12 * s; p[BI["torso"]][2] = 0.05 * s
    p[BI["head"]][0] = 0.08; p[BI["head"]][1] = -0.10 * s; p[BI["head"]][2] = 0.06 * math.sin(2 * phi + 0.5)
    p[BI["root"]][2] = 0.03 * s
    return p

def air_pose():
    p = Z()
    p[BI["uarmL"]] = (-0.3, 0, 1.9); p[BI["uarmR"]] = (-0.3, 0, -1.9)
    p[BI["farmL"]] = (-0.2, 0, 0.1); p[BI["farmR"]] = (-0.2, 0, -0.1)
    p[BI["thighL"]] = (-0.7, 0, 0.05); p[BI["shinL"]] = (1.1, 0, 0)
    p[BI["thighR"]] = (0.25, 0, -0.05); p[BI["shinR"]] = (0.6, 0, 0)
    p[BI["torso"]][0] = -0.05; p[BI["head"]][0] = 0.05; p[BI["head"]][2] = 0.1
    return p

def crouch_pose():
    p = Z()
    p[BI["thighL"]] = (-1.05, 0, 0.10); p[BI["thighR"]] = (-1.05, 0, -0.10)
    p[BI["shinL"]][0] = 1.6; p[BI["shinR"]][0] = 1.6
    p[BI["torso"]][0] = -0.25; p[BI["head"]][0] = 0.25
    p[BI["uarmL"]][0] = -0.5; p[BI["uarmR"]][0] = -0.5
    p[BI["farmL"]][0] = -0.5; p[BI["farmR"]][0] = -0.5
    return p

# ---------------------------------------------------------------- ekspor
def fa(arr):  # array float -> teks C
    return ",".join("%.4ff" % v for v in np.asarray(arr).ravel())

def export(M, path):
    used = set()
    for t in M.T: used.update(t)
    order = sorted([i for i in range(len(M.P)) if i in used], key=lambda i: (M.B[i], i))
    remap = {old: new for new, old in enumerate(order)}
    nv = len(order); nt = len(M.T)
    first = [0] * (NB + 1)
    for b in range(NB + 1): first[b] = sum(1 for i in order if M.B[i] < b)
    foot = {}
    for b in (BI["shinL"], BI["shinR"]):
        idx = [remap[i] for i in order if M.B[i] == b and M.tag[i] == "foot"]
        assert idx == list(range(idx[0], idx[0] + len(idx))) and idx[-1] + 1 == first[b + 1]
        foot[b] = (idx[0], len(idx))
    o = []
    o.append("/* DIBUAT OTOMATIS oleh tools/gen_mushroom.py - jangan diedit manual */")
    o.append("#define MUSH_NV %d\n#define MUSH_NT %d\n#define MUSH_NB %d\n#define MUSH_NWALK 16\n#define MUSH_NIDLE 12" % (nv, nt, NB))
    o.append("static const signed char mush_parent[MUSH_NB]={%s};" % ",".join(str(x) for x in PARENT))
    o.append("static const float mush_pivot[MUSH_NB][3]={%s};" % fa(PIVOT))
    o.append("static const int mush_first[MUSH_NB+1]={%s};" % ",".join(str(x) for x in first))
    o.append("#define MUSH_FOOT_BONE_L %d\n#define MUSH_FOOT_BONE_R %d" % (BI["shinL"], BI["shinR"]))
    o.append("#define MUSH_FOOT_FIRST_L %d\n#define MUSH_FOOT_COUNT_L %d" % foot[BI["shinL"]])
    o.append("#define MUSH_FOOT_FIRST_R %d\n#define MUSH_FOOT_COUNT_R %d" % foot[BI["shinR"]])
    pos = np.array([M.P[i] - PIVOT[M.B[i]] for i in order]); nrm = np.array([M.N[i] for i in order])
    col = np.array([M.C[i] for i in order])
    o.append("static const float mush_pos[MUSH_NV][3]={%s};" % fa(pos))
    o.append("static const float mush_nrm[MUSH_NV][3]={%s};" % fa(nrm))
    o.append("static const unsigned char mush_col[MUSH_NV][3]={%s};" % ",".join(str(int(x)) for x in col.ravel()))
    o.append("static const unsigned short mush_tri[MUSH_NT][3]={%s};" % ",".join("%d,%d,%d" % tuple(remap[v] for v in t) for t in M.T))
    walk = np.array([walk_pose(2 * math.pi * k / 16) for k in range(16)])
    idle = np.array([idle_pose(2 * math.pi * k / 12) for k in range(12)])
    o.append("static const float mush_walk[16][MUSH_NB][3]={%s};" % fa(walk))
    o.append("static const float mush_idle[12][MUSH_NB][3]={%s};" % fa(idle))
    o.append("static const float mush_air[1][MUSH_NB][3]={%s};" % fa(air_pose()))
    o.append("static const float mush_crouch[1][MUSH_NB][3]={%s};" % fa(crouch_pose()))
    open(path, "w").write("\n".join(o) + "\n")
    top = max(M.P[i][1] for i in order)
    print("vertex=%d segitiga=%d tinggi=%.2f" % (nv, nt, top))

if __name__ == "__main__":
    export(build(), "mushroom_model.h")
