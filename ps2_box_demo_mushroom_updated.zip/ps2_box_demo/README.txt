PS2 BOX DEMO -> JAMUR IMUT (PS2DEV + gsKit + libpad)

Update:
- Karakter kotak putih diganti karakter jamur merah-putih.
- Mesh 3D dan warna berasal dari mushroom_model.h yang dibuat oleh tools/gen_mushroom.py.
- Menggunakan data rangka 13 tulang dan animasi idle, walk, air/jump, serta crouch dari generator.
- Gerak pemain, kamera, ruangan, dan kontrol dasar tetap dari contoh awal.

Kontrol:
- Stick kiri / D-pad: bergerak
- Stick kanan: putar kamera
- Segitiga: loncat
- X: jongkok

Build di GitHub Codespaces/Linux dengan Docker dan toolchain PS2DEV:
  bash build.sh

Output: boxdemo.iso dan BOXDEMO.ELF

Catatan:
- build.sh memakai image Docker ps2dev/ps2dev:latest; perlu Docker aktif dan akses internet saat image belum ada.
- Generator sumber ada di tools/gen_mushroom.py; header yang dipakai build sudah disertakan.
- Jika ingin membuat ulang header, pastikan Python dan NumPy tersedia, lalu jalankan dari folder proyek:
    python3 tools/gen_mushroom.py
  Script menghasilkan mushroom_model.h di direktori kerja saat dijalankan.
- Rendering karakter memakai CPU dan software clipping, jadi performa tergantung jumlah segitiga serta emulator/perangkat.
