/*
 * BOX DEMO - contoh game 3D PS2 (PS2DEV + gsKit + libpad)
 *
 * Kontrol:
 *   Stick kiri / D-pad : maju, mundur, kiri, kanan (relatif kamera)
 *   Stick kanan        : putar kamera
 *   Segitiga           : loncat
 *   X (tahan)          : jongkok
 *
 * Karakter: jamur imut berwarna dengan mesh dan animasi dari mushroom_model.h.
 * Proyeksi 3D dihitung manual di CPU, gsKit hanya menggambar segitiga + z-buffer.
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <tamtypes.h>
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <libpad.h>
#include <gsKit.h>
#include <dmaKit.h>
#include <string.h>
#include "mushroom_model.h"

/* ---------------- pengaturan (silakan diubah) ---------------- */
#define ROOM_HALF     12.0f   /* setengah lebar ruangan */
#define ROOM_HEIGHT    8.0f   /* tinggi ruangan */
#define TILE           2.0f   /* ukuran ubin lantai */
#define NEAR_Z         0.2f   /* jarak clipping dekat */
#define DT          (1.0f/60.0f)

#define HALF_W         0.5f   /* setengah lebar kotak */
#define STAND_H        1.0f   /* tinggi kotak berdiri */
#define CROUCH_H       0.5f   /* tinggi kotak jongkok */
#define MOVE_SPEED     6.0f
#define CROUCH_SPEED   2.5f
#define JUMP_VEL       9.0f
#define GRAVITY       24.0f

#define CAM_DIST       6.5f
#define CAM_HEIGHT     3.2f
#define CAM_TURN_SPEED 2.2f   /* rad/detik pada stick kanan */
#define FOV_DEG       60.0f

#define PAD_MODE_DUALSHOCK_ID 7
#define PI_F 3.14159265f

/* ---------------- matematika kecil ---------------- */
typedef struct { float x, y, z; } V3;

static V3 v3(float x, float y, float z) { V3 r = { x, y, z }; return r; }
static V3 sub(V3 a, V3 b) { return v3(a.x - b.x, a.y - b.y, a.z - b.z); }
static float dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static V3 cross(V3 a, V3 b)
{
    return v3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x);
}
static V3 norm(V3 a)
{
    float l = sqrtf(dot(a, a));
    if (l < 1e-6f) return a;
    return v3(a.x / l, a.y / l, a.z / l);
}
static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static float wrap_pi(float a)
{
    while (a > PI_F) a -= 2.0f * PI_F;
    while (a < -PI_F) a += 2.0f * PI_F;
    return a;
}

/* ---------------- grafis ---------------- */
static GSGLOBAL *gs;
static V3 camPos, camR, camU, camF;
static float focal, scrCX, scrCY;

static void init_gs(void)
{
    gs = gsKit_init_global();
    gs->PSM = GS_PSM_CT24;
    gs->PSMZ = GS_PSMZ_24;
    gs->ZBuffering = GS_SETTING_ON;
    gs->DoubleBuffering = GS_SETTING_ON;

    dmaKit_init(D_CTRL_RELE_OFF, D_CTRL_MFD_OFF, D_CTRL_STS_UNSPEC,
                D_CTRL_STD_OFF, D_CTRL_RCYC_8, 1 << DMA_CHANNEL_GIF);
    dmaKit_chan_init(DMA_CHANNEL_GIF);
    dmaKit_chan_init(DMA_CHANNEL_FROMSPR);
    dmaKit_chan_init(DMA_CHANNEL_TOSPR);

    gsKit_init_screen(gs);
    gsKit_mode_switch(gs, GS_ONESHOT);
    gsKit_set_test(gs, GS_ZTEST_ON);

    scrCX = gs->Width / 2.0f;
    scrCY = gs->Height / 2.0f;
    focal = (gs->Height / 2.0f) / tanf((FOV_DEG * 0.5f) * PI_F / 180.0f);
}

static V3 to_view(V3 p)
{
    V3 d = sub(p, camPos);
    return v3(dot(d, camR), dot(d, camU), dot(d, camF));
}

static void emit_tri(V3 a, V3 b, V3 c, u64 col)
{
    float sx[3], sy[3];
    int sz[3];
    V3 p[3];
    int i;
    p[0] = a; p[1] = b; p[2] = c;
    for (i = 0; i < 3; i++) {
        float inv = 1.0f / p[i].z;
        sx[i] = scrCX + p[i].x * focal * inv;
        sy[i] = scrCY - p[i].y * focal * inv;
        sz[i] = (int)(clampf(NEAR_Z * inv, 0.0f, 1.0f) * 16000000.0f); /* besar = dekat */
    }
    gsKit_prim_triangle_3d(gs, sx[0], sy[0], sz[0], sx[1], sy[1], sz[1],
                           sx[2], sy[2], sz[2], col);
}

/* Render segitiga RGB untuk mesh karakter; ruangan tetap memakai grayscale. */
static void emit_tri_rgb(V3 a, V3 b, V3 c, u8 r, u8 g, u8 bcol)
{
    float sx[3], sy[3];
    int sz[3], i;
    V3 p[3];
    p[0] = a; p[1] = b; p[2] = c;
    for (i = 0; i < 3; i++) {
        float inv = 1.0f / p[i].z;
        sx[i] = scrCX + p[i].x * focal * inv;
        sy[i] = scrCY - p[i].y * focal * inv;
        sz[i] = (int)(clampf(NEAR_Z * inv, 0.0f, 1.0f) * 16000000.0f);
    }
    gsKit_prim_triangle_3d(gs, sx[0], sy[0], sz[0], sx[1], sy[1], sz[1],
                           sx[2], sy[2], sz[2], GS_SETREG_RGBAQ(r, g, bcol, 0x80, 0x00));
}

/* clip polygon (koordinat view) terhadap satu bidang: jarak >= 0 dianggap di dalam */
#define MAX_POLY 10
#define GUARD_PX 1800.0f   /* GS cuma kuat ~±2048 px dari tengah layar */

static float plane_dist(int pl, V3 p, float k)
{
    switch (pl) {
    case 0:  return p.z - NEAR_Z;
    case 1:  return k * p.z - p.x;
    case 2:  return k * p.z + p.x;
    case 3:  return k * p.z - p.y;
    default: return k * p.z + p.y;
    }
}

static int clip_plane(const V3 *in, int n, V3 *out, int pl, float k)
{
    int i, m = 0;
    for (i = 0; i < n; i++) {
        V3 p = in[i], q = in[(i + 1) % n];
        float dp = plane_dist(pl, p, k), dq = plane_dist(pl, q, k);
        if (dp >= 0.0f) out[m++] = p;
        if ((dp >= 0.0f) != (dq >= 0.0f)) {
            float t = dp / (dp - dq);
            out[m++] = v3(p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t, p.z + (q.z - p.z) * t);
        }
    }
    return m;
}

/* segitiga dalam koordinat dunia, di-clip ke frustum (dekat + tepi layar) */
static void draw_tri(V3 a, V3 b, V3 c, float shade)
{
    V3 bufA[MAX_POLY], bufB[MAX_POLY];
    V3 *src = bufA, *dst = bufB, *tmp;
    int n = 3, i, pl;
    float k = GUARD_PX / focal;
    u8 g = (u8)(clampf(shade, 0.0f, 1.0f) * 255.0f);
    u64 col = GS_SETREG_RGBAQ(g, g, g, 0x80, 0x00);

    src[0] = to_view(a); src[1] = to_view(b); src[2] = to_view(c);
    for (pl = 0; pl < 5; pl++) {
        n = clip_plane(src, n, dst, pl, k);
        if (n < 3) return;
        tmp = src; src = dst; dst = tmp;
    }
    for (i = 1; i + 1 < n; i++) emit_tri(src[0], src[i], src[i + 1], col);
}

static void draw_tri_rgb(V3 a, V3 b, V3 c, u8 r, u8 g, u8 bcol, float shade)
{
    V3 bufA[MAX_POLY], bufB[MAX_POLY];
    V3 *src = bufA, *dst = bufB, *tmp;
    int n = 3, i, pl;
    float k = GUARD_PX / focal;
    src[0] = to_view(a); src[1] = to_view(b); src[2] = to_view(c);
    for (pl = 0; pl < 5; pl++) {
        n = clip_plane(src, n, dst, pl, k);
        if (n < 3) return;
        tmp = src; src = dst; dst = tmp;
    }
    r = (u8)clampf((float)r * shade, 0.0f, 255.0f);
    g = (u8)clampf((float)g * shade, 0.0f, 255.0f);
    bcol = (u8)clampf((float)bcol * shade, 0.0f, 255.0f);
    for (i = 1; i + 1 < n; i++) emit_tri_rgb(src[0], src[i], src[i + 1], r, g, bcol);
}

static void draw_quad(V3 a, V3 b, V3 c, V3 d, float shade)
{
    draw_tri(a, b, c, shade);
    draw_tri(a, c, d, shade);
}

/* cahaya sederhana: makin menghadap sumber cahaya makin putih */
static float lighting(V3 n)
{
    static const V3 L = { 0.35f, 0.80f, -0.48f };
    return clampf(0.62f + 0.38f * dot(n, L), 0.50f, 1.0f);
}

static void draw_room(void)
{
    const float R = ROOM_HALF, H = ROOM_HEIGHT;
    int ix, iz, n = (int)(2.0f * R / TILE);

    /* lantai kotak-kotak halus (supaya gerakan terasa) */
    for (ix = 0; ix < n; ix++) {
        for (iz = 0; iz < n; iz++) {
            float x0 = -R + ix * TILE, z0 = -R + iz * TILE;
            float s = lighting(v3(0, 1, 0)) * (((ix + iz) & 1) ? 0.84f : 0.93f);
            draw_quad(v3(x0, 0, z0), v3(x0 + TILE, 0, z0),
                      v3(x0 + TILE, 0, z0 + TILE), v3(x0, 0, z0 + TILE), s);
        }
    }
    /* langit-langit */
    draw_quad(v3(-R, H, -R), v3(R, H, -R), v3(R, H, R), v3(-R, H, R),
              lighting(v3(0, -1, 0)));
    /* dinding (normal menghadap ke dalam) */
    draw_quad(v3(R, 0, -R), v3(R, 0, R), v3(R, H, R), v3(R, H, -R), lighting(v3(-1, 0, 0)));
    draw_quad(v3(-R, 0, -R), v3(-R, H, -R), v3(-R, H, R), v3(-R, 0, R), lighting(v3(1, 0, 0)));
    draw_quad(v3(-R, 0, R), v3(-R, H, R), v3(R, H, R), v3(R, 0, R), lighting(v3(0, 0, -1)));
    draw_quad(v3(-R, 0, -R), v3(R, 0, -R), v3(R, H, -R), v3(-R, H, -R), lighting(v3(0, 0, 1)));
}

/* ---------------- pemain ---------------- */
typedef struct {
    V3 pos;        /* pos.y = dasar kotak */
    float vy;
    float h;       /* tinggi kotak saat ini */
    float face;    /* arah hadap (rad) */
    int onGround;
} Player;

static void draw_box(V3 c, float hx, float hy, float hz, float yaw)
{
    static const int F[6][4] = {
        { 0, 4, 6, 2 }, { 1, 3, 7, 5 }, { 0, 1, 5, 4 },
        { 2, 6, 7, 3 }, { 0, 2, 3, 1 }, { 4, 5, 7, 6 }
    };
    static const float N[6][3] = {
        { -1, 0, 0 }, { 1, 0, 0 }, { 0, -1, 0 }, { 0, 1, 0 }, { 0, 0, -1 }, { 0, 0, 1 }
    };
    float s = sinf(yaw), co = cosf(yaw);
    V3 p[8];
    int i, f;
    for (i = 0; i < 8; i++) {
        float lx = (i & 1) ? hx : -hx;
        float ly = (i & 2) ? hy : -hy;
        float lz = (i & 4) ? hz : -hz;
        p[i] = v3(c.x + lx * co + lz * s, c.y + ly, c.z - lx * s + lz * co);
    }
    for (f = 0; f < 6; f++) {
        V3 n = v3(N[f][0] * co + N[f][2] * s, N[f][1], -N[f][0] * s + N[f][2] * co);
        float sh = clampf(lighting(n) + 0.08f, 0.0f, 1.0f);
        draw_quad(p[F[f][0]], p[F[f][1]], p[F[f][2]], p[F[f][3]], sh);
    }
}

/* ---------------- karakter jamur + animasi rangka ---------------- */
static float mushroomClock = 0.0f;
static int mushroomMoving = 0;
static int mushroomCrouching = 0;
static int mushroomAirborne = 0;

static V3 rotate_xyz(V3 p, V3 a)
{
    float sx = sinf(a.x), cx = cosf(a.x);
    float sy = sinf(a.y), cy = cosf(a.y);
    float sz = sinf(a.z), cz = cosf(a.z);
    V3 q;
    q = v3(p.x, p.y * cx - p.z * sx, p.y * sx + p.z * cx);
    p = q;
    q = v3(p.x * cy + p.z * sy, p.y, -p.x * sy + p.z * cy);
    p = q;
    q = v3(p.x * cz - p.y * sz, p.x * sz + p.y * cz, p.z);
    return q;
}

/* Pivot disimpan dalam koordinat bind pose. Terapkan tulang anak ke root. */
static V3 deform_vertex(int vertex, const float pose[MUSH_NB][3])
{
    int bone = 0, b;
    V3 p;
    for (b = 0; b < MUSH_NB; b++) {
        if (vertex >= mush_first[b] && vertex < mush_first[b + 1]) { bone = b; break; }
    }
    p = v3(mush_pos[vertex][0] + mush_pivot[bone][0],
           mush_pos[vertex][1] + mush_pivot[bone][1],
           mush_pos[vertex][2] + mush_pivot[bone][2]);
    b = bone;
    while (b >= 0) {
        V3 pivot = v3(mush_pivot[b][0], mush_pivot[b][1], mush_pivot[b][2]);
        V3 local = sub(p, pivot);
        V3 ang = v3(pose[b][0], pose[b][1], pose[b][2]);
        p = rotate_xyz(local, ang);
        p = v3(p.x + pivot.x, p.y + pivot.y, p.z + pivot.z);
        b = mush_parent[b];
    }
    return p;
}

static V3 mushroom_world_vertex(int vertex, const float pose[MUSH_NB][3], const Player *pl)
{
    V3 p = deform_vertex(vertex, pose);
    float s = sinf(pl->face), c = cosf(pl->face);
    return v3(pl->pos.x + p.x * c + p.z * s,
              pl->pos.y + p.y,
              pl->pos.z - p.x * s + p.z * c);
}

static void draw_mushroom(const Player *pl)
{
    const float (*pose)[3];
    static V3 world[MUSH_NV];
    int i;
    if (mushroomAirborne) pose = mush_air[0];
    else if (mushroomCrouching) pose = mush_crouch[0];
    else if (mushroomMoving) pose = mush_walk[((int)(mushroomClock * 8.0f)) % MUSH_NWALK];
    else pose = mush_idle[((int)(mushroomClock * 3.0f)) % MUSH_NIDLE];

    for (i = 0; i < MUSH_NV; i++) world[i] = mushroom_world_vertex(i, pose, pl);

    /* Bayangan sederhana di lantai. */
    {
        float k = 0.62f - 0.17f * clampf(pl->pos.y / 3.0f, 0.0f, 1.0f);
        float x = pl->pos.x, z = pl->pos.z, y = 0.025f;
        draw_quad(v3(x-k,y,z-k), v3(x+k,y,z-k), v3(x+k,y,z+k), v3(x-k,y,z+k), 0.40f);
    }

    for (i = 0; i < MUSH_NT; i++) {
        int ia = mush_tri[i][0], ib = mush_tri[i][1], ic = mush_tri[i][2];
        V3 a = world[ia], b = world[ib], c = world[ic];
        V3 n = norm(cross(sub(b, a), sub(c, a)));
        float shade = lighting(n);
        unsigned int r = ((unsigned int)mush_col[ia][0] + mush_col[ib][0] + mush_col[ic][0]) / 3;
        unsigned int g = ((unsigned int)mush_col[ia][1] + mush_col[ib][1] + mush_col[ic][1]) / 3;
        unsigned int bl = ((unsigned int)mush_col[ia][2] + mush_col[ib][2] + mush_col[ic][2]) / 3;
        draw_tri_rgb(a, b, c, (u8)r, (u8)g, (u8)bl, shade);
    }
}

static void draw_player(const Player *pl)
{
    draw_mushroom(pl);
}

/* ---------------- input ---------------- */
static char padBuf[256] __attribute__((aligned(64)));

typedef struct { u32 btn; float lx, ly, rx, ry; } Input;

static void load_modules(void)
{
    SifInitRpc(0);
    if (SifLoadModule("rom0:XSIO2MAN", 0, NULL) < 0) SifLoadModule("rom0:SIO2MAN", 0, NULL);
    if (SifLoadModule("rom0:XPADMAN", 0, NULL) < 0) SifLoadModule("rom0:PADMAN", 0, NULL);
}

static void pad_wait_ready(void)
{
    int tries = 0, st;
    do {
        volatile int k;
        for (k = 0; k < 200000; k++) { }
        st = padGetState(0, 0);
    } while (st != PAD_STATE_STABLE && st != PAD_STATE_FINDCTP1 && ++tries < 300);
}

static void pad_setup(void)
{
    padInit(0);
    padPortOpen(0, 0, padBuf);
    pad_wait_ready();
    padSetMainMode(0, 0, PAD_MMODE_DUALSHOCK, PAD_MMODE_LOCK);
    pad_wait_ready();
}

static float deadzone(float v)
{
    if (fabsf(v) < 0.22f) return 0.0f;
    return clampf(v, -1.0f, 1.0f);
}

static Input input_read(void)
{
    Input in = { 0, 0, 0, 0, 0 };
    struct padButtonStatus b;
    int st = padGetState(0, 0);
    if (st != PAD_STATE_STABLE && st != PAD_STATE_FINDCTP1) return in;
    if (padRead(0, 0, &b) == 0) return in;

    in.btn = 0xffff ^ b.btns;
    if (padInfoMode(0, 0, PAD_MODECURID, 0) == PAD_MODE_DUALSHOCK_ID) {
        in.lx = deadzone((b.ljoy_h - 128) / 128.0f);
        in.ly = deadzone((b.ljoy_v - 128) / 128.0f);
        in.rx = deadzone((b.rjoy_h - 128) / 128.0f);
        in.ry = deadzone((b.rjoy_v - 128) / 128.0f);
    }
    return in;
}

/* ---------------- logika game ---------------- */
static float camYaw = 0.0f;

static void update(Player *pl, const Input *in, u32 prevBtn)
{
    float mx = in->lx, mz = -in->ly;          /* stick atas = maju */
    float fx, fz, rx, rz, wx, wz, len, speed, target;
    int crouch, jumpPressed;

    if (in->btn & PAD_LEFT)  mx -= 1.0f;
    if (in->btn & PAD_RIGHT) mx += 1.0f;
    if (in->btn & PAD_UP)    mz += 1.0f;
    if (in->btn & PAD_DOWN)  mz -= 1.0f;
    len = sqrtf(mx * mx + mz * mz);
    if (len > 1.0f) { mx /= len; mz /= len; len = 1.0f; }

    camYaw += in->rx * CAM_TURN_SPEED * DT;

    fx = sinf(camYaw); fz = cosf(camYaw);      /* arah depan kamera */
    rx = cosf(camYaw); rz = -sinf(camYaw);     /* arah kanan kamera */
    wx = rx * mx + fx * mz;
    wz = rz * mx + fz * mz;

    crouch = ((in->btn & PAD_CROSS) != 0) && pl->onGround;
    speed = crouch ? CROUCH_SPEED : MOVE_SPEED;
    pl->pos.x += wx * speed * DT;
    pl->pos.z += wz * speed * DT;
    pl->pos.x = clampf(pl->pos.x, -(ROOM_HALF - HALF_W), ROOM_HALF - HALF_W);
    pl->pos.z = clampf(pl->pos.z, -(ROOM_HALF - HALF_W), ROOM_HALF - HALF_W);

    jumpPressed = (in->btn & PAD_TRIANGLE) && !(prevBtn & PAD_TRIANGLE);
    if (jumpPressed && pl->onGround && !crouch) {
        pl->vy = JUMP_VEL;
        pl->onGround = 0;
    }
    pl->vy -= GRAVITY * DT;
    pl->pos.y += pl->vy * DT;
    if (pl->pos.y <= 0.0f) {
        pl->pos.y = 0.0f;
        pl->vy = 0.0f;
        pl->onGround = 1;
    } else {
        pl->onGround = 0;
    }

    target = crouch ? CROUCH_H : STAND_H;
    pl->h += (target - pl->h) * clampf(20.0f * DT, 0.0f, 1.0f);

    if (len > 0.1f) {
        float want = atan2f(wx, wz);
        pl->face += wrap_pi(want - pl->face) * clampf(12.0f * DT, 0.0f, 1.0f);
    }
}

static void setup_camera(const Player *pl)
{
    V3 tgt = v3(pl->pos.x, pl->pos.y + 0.6f, pl->pos.z);
    float lim = ROOM_HALF - 0.4f;

    camPos = v3(tgt.x - sinf(camYaw) * CAM_DIST,
                CAM_HEIGHT + pl->pos.y * 0.3f,
                tgt.z - cosf(camYaw) * CAM_DIST);
    camPos.x = clampf(camPos.x, -lim, lim);
    camPos.z = clampf(camPos.z, -lim, lim);
    camPos.y = clampf(camPos.y, 0.5f, ROOM_HEIGHT - 0.4f);

    camF = norm(sub(tgt, camPos));
    camR = norm(cross(v3(0, 1, 0), camF));
    camU = cross(camF, camR);
}

int main(void)
{
    Player pl = { { 0.0f, 0.0f, 0.0f }, 0.0f, STAND_H, 0.0f, 1 };
    u32 prev = 0;

    load_modules();
    init_gs();
    pad_setup();

    while (1) {
        Input in = input_read();
        update(&pl, &in, prev);
        prev = in.btn;
        mushroomMoving = (fabsf(in.lx) > 0.22f || fabsf(in.ly) > 0.22f ||
                          (in.btn & (PAD_LEFT | PAD_RIGHT | PAD_UP | PAD_DOWN)) != 0);
        mushroomCrouching = ((in.btn & PAD_CROSS) != 0) && pl.onGround;
        mushroomAirborne = !pl.onGround;
        mushroomClock += DT;
        setup_camera(&pl);

        gsKit_clear(gs, GS_SETREG_RGBAQ(0x20, 0x20, 0x20, 0x00, 0x00));
        draw_room();
        draw_player(&pl);

        gsKit_queue_exec(gs);
        gsKit_sync_flip(gs);
    }
    return 0;
}
