#!/bin/bash
# Build ELF di dalam docker PS2DEV, lalu bikin ISO.
# Jalankan dari folder ini:  bash build.sh
set -e
cd "$(dirname "$0")"

echo "== 1/3 Compile ELF =="
docker run --rm -v "$PWD":/src -w /src ps2dev/ps2dev:latest \
  sh -c "make clean && make"

echo "== 2/3 Siapkan isi ISO =="
rm -rf iso && mkdir iso
cp BOXDEMO.ELF iso/BOXDEMO.ELF
printf 'BOOT2 = cdrom0:\\BOXDEMO.ELF;1\r\nVER = 1.00\r\nVMODE = NTSC\r\n' > iso/SYSTEM.CNF

echo "== 3/3 Bikin ISO =="
if command -v mkisofs >/dev/null 2>&1; then
  mkisofs -l -iso-level 1 -V BOXDEMO -o boxdemo.iso iso
elif command -v genisoimage >/dev/null 2>&1; then
  genisoimage -l -iso-level 1 -V BOXDEMO -o boxdemo.iso iso
else
  xorriso -as mkisofs -l -iso-level 1 -V BOXDEMO -o boxdemo.iso iso
fi

echo "Selesai: boxdemo.iso dan BOXDEMO.ELF"
